package Engine;

import Sprites.*;

import javax.swing.*;
import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;

/**
 * Created by sagi on 12/18/15.
 */



public class GameEngine implements KeyListener {
    private final String BASE_PATH = System.getProperty("user.dir") + File.separator +"src"+ File.separator;
    private final int LARGE=100, MEDIUM=50, SMALL=25, NUM_OF_LIVES = 3;
    private final int STOP=0, UP=1, DOWN=-1;
    public boolean gameOn,fireLock, gameOver, isFirstGame;
    private Ship player;
    private Vector<Sprite> astroidsSprites,laserSprites;
    private int pWidth, pHeight;
    private Timer astroidTimer, fireTimer, startTime;
    private Random r;
    private int score, countDown;
    private Vector<Sprite> lives, fogs;
    private File laserSoundFile;
    private final String laserSoundPath = BASE_PATH + "Sounds" + File.separator + "laser.wav";
    private AudioClip laserAudioClip;

    private File themeFile;
    private final String themeSoundPath = BASE_PATH + "Sounds" + File.separator + "theme.wav";
    private AudioClip themeAudioClip;

    public GameEngine(int width, int height){
        this.isFirstGame = true;
        this.gameOver = true;
        this.pWidth = width;
        this.pHeight = height;
        laserSoundFile = new File(laserSoundPath);
        themeFile = new File(themeSoundPath);
        try {
            laserAudioClip = Applet.newAudioClip(laserSoundFile.toURL());
            themeAudioClip = Applet.newAudioClip(themeFile.toURL());
        }catch (Exception e){
            laserAudioClip = null;
            themeAudioClip = null;
        }
        if(themeAudioClip != null)
            themeAudioClip.loop();
        fogs = new Vector<>();
        r = new Random();
        initFogs();
        startNewGame();
    }

    private void initFogs(){
        for(int i = 0 ; i < 4 ; i++){
            fogs.add(new Fog((-1)*r.nextInt(),(-1)*r.nextInt(),pWidth,pHeight,1,"Fog.png",r.nextInt(360),pWidth));
        }
    }

    private void startNewGame(){
        score = 0;
        lives = new Vector<>();
        setupLives(NUM_OF_LIVES);
        astroidTimer = new Timer(5000, new astroidTimerListener()) ;
        fireTimer = new Timer(500, new fireTimerListener()) ;
        startTime = new Timer(1000, new countDownListener());
        fogs.remove(fogs.size()-1);
        initGame();
    }

    private void initGame(){
        this.countDown = 3;
        astroidsSprites = new Vector<>();
        laserSprites = new Vector<>();
        this.player = new Ship(pWidth/2, pHeight/2,pWidth,pHeight, MEDIUM);
        gameOn = true;
        fireTimer.start();
        astroidTimer.start();

        for (int i =0 ; i<4 ; i++)
            createAstroid();
    }

    private void setupLives(int num){
        int size = 30;
        for(int i = 0 ; i < num ; i++){
            lives.add(new Ship(pWidth - ((i+1)*size), 15, pWidth, pHeight, size));
        }
    }

    public int getScore(){
        return score;
    }

    public boolean isGameOver(){
        return this.gameOver;
    }

    public int getCountDown(){
        return countDown;
    }

    private void createAstroid(){
        astroidsSprites.add(new Astroid((-1)*r.nextInt(),(-1)*r.nextInt(),pWidth,pHeight,1,"astroid.png",r.nextInt(360),LARGE));
    }

    @Override
    public void keyTyped(KeyEvent keyEvent) {
    }

    @Override
    public void keyPressed(KeyEvent keyEvent) {
        if(gameOn) {
            switch (keyEvent.getKeyCode()) {
                case KeyEvent.VK_UP:
                    player.setDirection(UP);
                    break;
                case KeyEvent.VK_DOWN:
                    player.setDirection(DOWN);
                    break;
                case KeyEvent.VK_LEFT:
                    player.turnShip(DOWN);
                    break;
                case KeyEvent.VK_RIGHT:
                    player.turnShip(UP);
                    break;
                case KeyEvent.VK_SPACE:
                    if (!fireLock) {
                        if(laserAudioClip != null)
                            laserAudioClip.play();
                        laserSprites.add(new LaserBlast((int) player.getLocX() + (player.getImageWidth() / 2),
                                (int) player.getLocY() + (player.getImageHeight() / 2),
                                pWidth,
                                pHeight,
                                6,
                                "laser.gif",
                                player.getAngle(),
                                SMALL));
                        fireLock = true;
                    }
                    break;
                case KeyEvent.VK_F2:
                    this.isFirstGame = false;
                    gameOver = false;
                    startNewGame();
                    startTime.start();
                    break;

                default:
                    break;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent keyEvent) {
        if(gameOn){
            switch (keyEvent.getKeyCode()){
                case KeyEvent.VK_UP:
                case KeyEvent.VK_DOWN:
                    player.setDirection(STOP);
                    break;
                case KeyEvent.VK_RIGHT:
                case KeyEvent.VK_LEFT:
                    player.turnShip(STOP);
                    break;

                default:
                    break;

            }
        }


    }

    public void update(){
        for (Sprite sprite : fogs) {
            sprite.update();
        }
        if(!gameOver) {
            if (countDown > 0)
                return;
        }
        else
            return;

        Vector<Sprite> newAstroids = new Vector<>();
        Vector<Sprite> removeLasers = new Vector<>();
        Vector<Sprite> removeAstroids = new Vector<>();

        player.update();
        for (Sprite sprite : astroidsSprites) {
            sprite.update();
        }
        for (Sprite sprite : laserSprites) {
            sprite.update();
        }





        for (int i = 0; i<laserSprites.size(); i++){
            for (int j = 0; j<astroidsSprites.size(); j++){

                if(CollisionUtil.collidesWith(laserSprites.get(i), astroidsSprites.get(j))) {
                    score+=100;
                    if (astroidsSprites.get(j).getSize() == LARGE) {
                        for (int k = 0; k < 2; k++) {
                            newAstroids.add(new Astroid((int) astroidsSprites.get(j).getLocX(), (int) astroidsSprites.get(j).getLocY(), pWidth, pHeight, astroidsSprites.get(j).getAcceleration(), "astroid.png", r.nextInt(360), MEDIUM));
                        }
                    } else if (astroidsSprites.get(j).getSize() == MEDIUM) {
                        for (int h = 0; h < 2; h++) {
                            newAstroids.add(new Astroid((int) astroidsSprites.get(j).getLocX(), (int) astroidsSprites.get(j).getLocY(), pWidth, pHeight, astroidsSprites.get(j).getAcceleration(), "astroid.png", r.nextInt(360), SMALL));
                        }
                        score+=100;
                    }else{
                        score+=200;
                    }

                    removeLasers.add(laserSprites.get(i));
                    removeAstroids.add(astroidsSprites.get(j));
                }
            }
        }

        for(int i = 0 ; i < astroidsSprites.size() ; i++){
            if(CollisionUtil.collidesWith(astroidsSprites.get(i), player)){
                if(lives.size() == 1){
                    gameOver = true;
                    fogs.add(new Fog(pWidth,0,pWidth,pHeight,1,"Fog.png",180,pWidth));
                }
                if(lives.size() > 0)
                    lives.remove(lives.size()-1);
                initGame();
                System.out.println("==============GAME OVER==============");
            }
        }



        astroidsSprites.addAll(newAstroids);

        laserSprites.removeAll(removeLasers);
        astroidsSprites.removeAll(removeAstroids);

    }

    public void render(){

    }

    public void drawSprites(Graphics g, JPanel panel){
        if(!gameOver)
            player.drawSprite(g, panel);
        try {
            for (Sprite sprite : astroidsSprites) {
                sprite.drawSprite(g, panel);
            }
            for (Sprite sprite : laserSprites) {
                sprite.drawSprite(g, panel);
            }
            for (Sprite sprite : lives) {
                sprite.drawSprite(g, panel);
            }
            for (Sprite sprite : fogs) {
                sprite.drawSprite(g, panel);
            }
        }catch (Exception e)
        {

        }
    }


private class astroidTimerListener implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        createAstroid();
    }
}
private class fireTimerListener implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        fireLock = false;
    }
}

    private class countDownListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            countDown--;

        }
    }


}
