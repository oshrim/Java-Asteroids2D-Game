package Sprites;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Created by sagi on 12/18/15.
 */
public class Ship extends Sprite {

    private final int STOP=0, UP=1, DOWN=-1;
    private final double MAX_SPEED = 3, SLOWING_FACTOR = 0.00000001;
    private int direction, turnDirection;
    private BufferedImage bi;


    public Ship(int x, int y, int w, int h, int size) {
        super(x, y, w, h, 0, "ship2.png", 0, size);
        direction = STOP;
        turnDirection = STOP;

    }

    @Override
    public void update() {
        setSpeed();
        this.angle+=3*turnDirection;
        locX += acceleration * Math.cos(Math.toRadians(angle));
        locY -= acceleration * (-1 * Math.sin(Math.toRadians(angle)));
        outOfScreeFix();

    }

    private void setSpeed(){
        if (direction == UP && !(acceleration > MAX_SPEED)){
            acceleration++;
        }
        else if (direction == DOWN && (acceleration > MAX_SPEED*(-1))){
            acceleration--;
        }
        else { //slowing down
            if (acceleration > 0) {
                acceleration -= SLOWING_FACTOR;
                if (acceleration < 0) {
                    acceleration = 0;
                }
            }
            if (acceleration < 0) {
                acceleration += SLOWING_FACTOR;
                if (acceleration > 0) {
                    acceleration = 0;
                }
            }
        }
//        System.out.println(acceleration);
    }

    public void setDirection(int direction){
        this.direction = direction;
    }


    public void drawSprite(Graphics g, JPanel panel) {
        Graphics2D g2d = (Graphics2D)g;
        g2d.rotate(Math.toRadians(angle), locX + (bImage.getWidth()/2), locY + (bImage.getHeight()/2));
        g2d.drawImage(bImage, (int)locX, (int)locY, panel);
        g2d.rotate(-1*Math.toRadians(angle), locX + (bImage.getWidth()/2), locY + (bImage.getHeight()/2));

    }
    public void turnShip(int direction){
        turnDirection=direction;
    }

}
